package fonctions;

public class bonjour {
	public static void bonjour(String nom) {
		System.out.println();
		System.out.println("Bien le bonjour, ceci est un programme qui "+nom);
		System.out.println();
	}
}